 var express = require('express');
 var router = express.Router();
 var ApplyJobs=require('../models/Status');
 router.post('/Apply_Jobs/',function(req,res,next)
{ 
try 
{
  ApplyJobs.Apply_Jobs(req.body, function (err, rows) 
{
if (err) 
{
res.json(err);
}
else 
{
res.json(rows);
}
});
}
catch (e) 
{
}
finally 
{
}
});

router.get('/Search_Job_Mobile/',function(req,res,next)
{ 
try 
{
  
  ApplyJobs.Search_Job_Mobile(req.query.Student_Id_,req.query.Pointer_Start_,req.query.Pointer_Stop_,req.query.Page_Length_, function (err, rows) 
{
 if (err)                                                                                                                                                     
 {
   
 res.json(err);
 }
 else 
 {
 // 
   res.json(rows);
 }
 });
 }
catch (e) 
{
 
}
finally 
{
}
 });


 router.get("/Change_Student_Status/", function (req, res, next) {
	try {
		ApplyJobs.Change_Student_Status(
			req.query.Student_Status_,
			req.query.Student_Id_,
			function (err, rows) {
				if (err) {
					console.log(err);

					res.json(err);
				} else {
					console.log(rows);
					res.json(rows);
				}
			}
		);
	} catch (e) {
		console.log(e);
	} finally {
	}
});



  module.exports = router;

